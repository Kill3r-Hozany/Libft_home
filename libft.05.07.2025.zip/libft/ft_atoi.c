/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/15 16:35:40 by elsoares          #+#    #+#             */
/*   Updated: 2025/07/05 17:47:59 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

static int	check_over(long resultado, const char *ptr, int signal)
{
	if (resultado > (LONG_MAX - (*ptr - '0' ) / 10))
	{
		if (signal == 1)
			return (-1);
		return (0);
	}
	return (1);
}

int	ft_atoi(const char *nptr)
{
	int		sinal;
	int		n;
	long	resultado;

	if (!nptr)
		return (0);
	resultado = 0;
	sinal = 1;
	while (*nptr == ' ' || (*nptr >= 9 && *nptr <= 13))
		nptr++;
	if (*nptr == '-' || *nptr == '+')
	{
		if (*nptr == '-')
			sinal = -1;
		nptr++;
	}
	while (*nptr >= '0' && *nptr <= '9' )
	{
		n = check_over(resultado, nptr, sinal);
		if (n != 1)
			return (n);
		resultado = resultado * 10 + *nptr - '0';
		nptr++;
	}
	return ((int)(resultado * sinal));
}
