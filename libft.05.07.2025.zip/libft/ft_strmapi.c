/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/24 14:35:15 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/24 15:15:12 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	char	*novo;
	size_t	tamanho;
	size_t	indice;

	if (!s || !f)
		return (NULL);
	indice = 0;
	tamanho = ft_strlen(s);
	novo = (char *)malloc(sizeof(char) * (tamanho + 1));
	if (!novo)
		return (NULL);
	while (indice < tamanho)
	{
		novo[indice] = (*f)(indice, s[indice]);
		++indice;
	}
	novo[indice] = 0;
	return (novo);
}
