/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/20 11:06:11 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/20 13:14:46 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

static char	*concatenar(char const *prefixo, char const *sufixo, size_t tamanho)
{
	char	*ponteiro;
	size_t	indice1;
	size_t	indice2;

	ponteiro = (char *)malloc(sizeof (char) * (tamanho + 1));
	if (!ponteiro)
		return (NULL);
	indice1 = 0;
	indice2 = 0;
	while (prefixo[indice1])
	{
		ponteiro[indice1] = prefixo[indice1];
		indice1++;
	}
	while (sufixo[indice2])
	{
		ponteiro[indice1] = sufixo[indice2];
		indice2++;
		indice1++;
	}
	ponteiro[indice1] = '\0';
	return (ponteiro);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	comprimento_total;

	if (!s1 && !s2)
		return (ft_strdup(""));
	if (s1 && !s2)
		return (ft_strdup(s1));
	if (!s1 && s2)
		return (ft_strdup(s2));
	comprimento_total = (ft_strlen(s1) + ft_strlen(s2));
	return (concatenar(s1, s2, comprimento_total));
}
