/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/16 12:05:35 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/16 18:59:19 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

char	*ft_strdup(const char *s)
{
	int		i;
	int		len_s;
	char	*novo_vetor;

	if (!s)
		return (NULL);
	len_s = 0;
	i = 0;
	while (s[len_s])
		len_s++;
	novo_vetor = (char *)malloc(sizeof(char) * (len_s + 1));
	if (!novo_vetor)
		return (NULL);
	while (i < len_s)
	{
		novo_vetor[i] = s[i];
		i++;
	}
	novo_vetor[i] = '\0';
	return (novo_vetor);
}
