/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/09 18:40:22 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/14 18:42:36 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

/*int	alfabeto(int c):
{
	return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
}

int	numero(int c)
{
	return (c >= '0' && c <= '9');
}
*/
int	ft_isalnum(int c)
{	
	return (ft_isdigit(c) || ft_isalpha(c));
}
/*
int	main(void)
{
	printf("%d",ft_isalnum('A'));
}*/
