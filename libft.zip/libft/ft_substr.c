/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/17 18:40:05 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/19 16:28:24 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

void	*protetor_contra_valores_invalidos(const char *entrada)
{
	if (!entrada)
		return (NULL);
	if (!*entrada)
		return (NULL);
	return ("Eliseu");
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	size_start;
	char	*ponteiro;
	size_t	i;
	size_t	y;

	if (protetor_contra_valores_invalidos(s) == NULL)
		return (NULL);
	y = ft_strlen(s);
	if (start > y || start < 0)
		return (ft_strdup(""));
	if (len > y - start)
		len = y - start;
	ponteiro = (char *)malloc(sizeof(char) * (len + 1));
	if (!ponteiro)
		return (NULL);
	i = 0;
	size_start = 0;
	while (s[start] && i < len)
	{
		ponteiro[i] = s[start];
		start++;
		i++;
	}
	ponteiro[i] = '\0';
	return (ponteiro);
}
/*
int     main(void)
{
        char    v[] = "Eliseu";

        printf("%s",ft_substr(v, 3, 3));
        return (0);
}*/
