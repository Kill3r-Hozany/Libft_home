/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                     +#+  +:+       +#+       */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/21 13:47:51 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/23 16:52:58 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

static void	release(char **vector)
{
	int	i;

	if (!vector)
		return ;
	i = 0;
	while (vector[i])
	{
		free (vector[i]);
		i++;
	}
	free(vector);
}

static int	allocator_aux(char const *string, char separator, char **ponteiro)
{
	char		**new_ptr;
	char const	*aux;

	new_ptr = ponteiro;
	aux = string;
	while (*string)
	{
		while (*string == separator)
			++string;
		aux = string;
		while (*aux && *aux != separator)
			++aux;
		if (aux > string)
		{
			*new_ptr = ft_substr(string, 0, aux - string);
			if (!*new_ptr)
				return (0);
			string = aux;
			++new_ptr;
		}
	}
	*new_ptr = (NULL);
	return (1);
}

static int	allocator(char **ptr, char const *string, char separator)
{
	if (allocator_aux(string, separator, ptr) == 0)
		return (0);
	return (1);
}

static int	count_word(const char *string, char separator)
{
	size_t	word;

	word = 0;
	while (*string)
	{
		while (*string == separator)
			++string;
		if (*string)
			++word;
		while (*string && *string != separator)
			++string;
	}
	return (word);
}

char	**ft_split(char const *s, char c)
{
	char	**new;
	int		amount_word;

	new = NULL;
	if (!s)
		return (NULL);
	amount_word = count_word(s, c);
	new = (char **)malloc(sizeof(char *) * (amount_word + 1));
	if (!new)
		return (NULL);
	if (allocator(new, s, c) == 0)
	{
		release(new);
		return (NULL);
	}
	return (new);
}
